﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using NotificationTester.Models;
using System.IO;
using System.Xml.Serialization;

namespace NotificationTester
{
    [HubName("notificationHub")]
    public class NotificationHub : Hub
    {
        [HubMethodName("returnApprovalCount")]
        public void ReturnApprovalCount()
        {
            int intUserID = 100;
            List <Employee> lstEmployee;
            string path = HttpContext.Current.Server.MapPath("EmployeeData.xml");
            if(!string.IsNullOrEmpty(path))
            {
                path = path.Replace("\\signalr", "");
            }
            
            using (StreamReader reader = new StreamReader(path))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(PBSEmployee));
                PBSEmployee PBS = (PBSEmployee)serializer.Deserialize(reader);
                lstEmployee = PBS.EmployeeList;
            }

            if (lstEmployee != null)
            {
                Employee employee = lstEmployee.FirstOrDefault(emp => emp.ID.Equals(Convert.ToInt32(intUserID)));
                if (employee != null)
                {
                    string strUser1 = Context.User.Identity.Name;
                    this.Clients.All.ReceiveNotification(employee.ApprovalCount);
                }
            }
        }
    }
}