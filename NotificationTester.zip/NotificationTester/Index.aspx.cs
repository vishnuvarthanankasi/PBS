﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace NotificationTester
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string strRole = "";
            string strUserID = Convert.ToString(Session["UserID"]);

            lblId.Text = Convert.ToString(Session["ID"]);
            lblName.Text = Convert.ToString(Session["Name"]);
            lblRole.Text = Convert.ToString(Session["Role"]);            

            if (Session["Role"] != null)
            {
                strRole = Session["Role"].ToString().ToUpper();
            }
            if (!Page.IsPostBack)
            {
                if (strRole.Equals("ADMIN"))
                {
                    BindGrid();
                }
            }
        }

        protected void GrdEmployee_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdEmployee.EditIndex = e.NewEditIndex;
            BindGrid();
        }

        protected void GrdEmployee_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow gRow = grdEmployee.Rows[e.RowIndex];
            int intItemIndex = gRow.DataItemIndex;

            string strId = ((TextBox)gRow.Cells[2].Controls[0]).Text;
            string strName = ((TextBox)gRow.Cells[3].Controls[0]).Text;
            string strPassword = ((TextBox)gRow.Cells[4].Controls[0]).Text;
            string strRole = ((TextBox)gRow.Cells[5].Controls[0]).Text;
            string strApprovalCount = ((TextBox)gRow.Cells[6].Controls[0]).Text;
            grdEmployee.EditIndex = -1;
            BindGrid();

            DataSet dSet = (DataSet)grdEmployee.DataSource;
            dSet.Tables[0].Rows[intItemIndex][0] = strId;
            dSet.Tables[0].Rows[intItemIndex][1] = strName;
            dSet.Tables[0].Rows[intItemIndex][2] = strPassword;
            dSet.Tables[0].Rows[intItemIndex][3] = strRole;
            dSet.Tables[0].Rows[intItemIndex][4] = strApprovalCount;
            dSet.WriteXml(Server.MapPath("EmployeeData.xml"));
            BindGrid();
        }
        private void BindGrid()
        {
            DataSet dataSet = new DataSet();
            dataSet.ReadXml(Server.MapPath("EmployeeData.xml"));
            grdEmployee.DataSource = dataSet;
            grdEmployee.DataBind();
        }
    }
}