﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NotificationTester.Models;
using System.Xml.Serialization;
using System.Web.Security;

namespace NotificationTester
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                string strName = ((TextBox)Login1.FindControl("UserName")).Text.ToUpper();
                string strPassword = ((TextBox)Login1.FindControl("Password")).Text;

                List<Employee> lstEmployee;
                string path = Server.MapPath("EmployeeData.xml");
                using (StreamReader reader = new StreamReader(path))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(PBSEmployee));
                    PBSEmployee PBS = (PBSEmployee)serializer.Deserialize(reader);
                    lstEmployee = PBS.EmployeeList;
                }

                if (lstEmployee != null)
                {
                    Employee employee = lstEmployee.FirstOrDefault(emp => (emp.Name.ToUpper() == strName && emp.Password == strPassword));
                    if (employee != null)
                    {
                        Session["ID"] = employee.ID;
                        Session["Name"] = employee.Name;
                        Session["Role"] = employee.Role;
                        Session["ApprovalCount"] = employee.ApprovalCount;

                        FormsAuthentication.SetAuthCookie(strName, Login1.RememberMeSet);
                        Response.Redirect("Index.aspx");
                    }
                    else
                    {
                        Login1.FailureText = "Login failed";
                    }
                }
            }
        }
    }
}