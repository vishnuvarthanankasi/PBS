﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace NotificationTester.Models
{
    public class Employee
    {
        [XmlElement("id")]
        public int ID { get; set; }
        [XmlElement("name")]
        public string Name { get; set; }
        [XmlElement("password")]
        public string Password { get; set; }
        [XmlElement("role")]
        public string Role { get; set; }
        [XmlElement("approvalcount")]
        public int ApprovalCount { get; set; }
    }
}