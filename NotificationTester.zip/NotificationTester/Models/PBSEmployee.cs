﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using NotificationTester.Models;

namespace NotificationTester.Models
{
    [XmlRoot("pbsemployee")]
    public class PBSEmployee
    {
        [XmlElement("employee", typeof(Employee))]
        public List<Employee> EmployeeList { get; set; }
    }
}