﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SignalRTest.Models
{
    [Serializable]
    public class Program
    {
        private List<Program> lstProgram = new List<Program>();

        public string Package { get; set; }
        public string Manifestation{ get; set; }
        public string ProgramTitle { get; set; }
        public string Dist { get; set; }
        public string Nola { get; set; }
        public string EstimatedDelivery { get; set; }
        public string ActualDelivery { get; set; }        
        public string Status { get; set; }

        public List<Program> Programs
        {
            get
            {   
                lstProgram.Add(new Program() { Package="121212-001", Manifestation="SD Base", Dist="PBS", ProgramTitle="American Masters", Nola="CIVW 0001001", EstimatedDelivery="11/5/2015", ActualDelivery="21/05/2015", Status="On Edgee" });
                lstProgram.Add(new Program() { Package = "121212-002", Manifestation = "Base", Dist = "APT", ProgramTitle = "Civil war", Nola = "CIVW 0001002", EstimatedDelivery = "21/5/2015", ActualDelivery = "25/05/2015", Status = "On Edgee" });
                lstProgram.Add(new Program() { Package = "121212-003", Manifestation = "HD Base", Dist = "PBS", ProgramTitle = "Civil war", Nola = "CIVW 0001003", EstimatedDelivery = "12/5/2015", ActualDelivery = "18/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-004", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "American Masters", Nola = "CIVW 0001004", EstimatedDelivery = "21/5/2015", ActualDelivery = "22/05/2015", Status = "On Edgee" });
                lstProgram.Add(new Program() { Package = "121212-005", Manifestation = "HD Base", Dist = "APT", ProgramTitle = "Civil war", Nola = "CIVW 0001005", EstimatedDelivery = "11/5/2015", ActualDelivery = "14/05/2015", Status = "On Edgee" });
                lstProgram.Add(new Program() { Package = "121212-006", Manifestation = "Base", Dist = "PBS", ProgramTitle = "Kids Time", Nola = "CIVW 0001006", EstimatedDelivery = "12/5/2015", ActualDelivery = "17/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-007", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-008", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Discovery Science", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-009", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-010", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Kids Time", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-011", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-012", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Kids Time", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-013", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-014", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Kids Time", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-015", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-016", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Discovery Science", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-017", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-018", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Kids Time", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-019", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-020", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Discovery Science", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-021", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-022", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "Discovery Science", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-023", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-024", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "Discovery Science", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-025", Manifestation = "SD Base", Dist = "PBS", ProgramTitle = "Kids Time", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                lstProgram.Add(new Program() { Package = "121212-026", Manifestation = "SD Base", Dist = "APT", ProgramTitle = "American Masters", Nola = "CIVW 0001007", EstimatedDelivery = "12/5/2015", ActualDelivery = "21/05/2015", Status = "Available" });
                return lstProgram;
            }

            set
            {
                lstProgram = value;
            }
        }
    }
}
