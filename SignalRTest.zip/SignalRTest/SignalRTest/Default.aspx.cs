﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SignalRTest.Models;

namespace SignalRTest
{
    public partial class Default : System.Web.UI.Page
    {
        List<Program> lstProgram = null;
        bool blnSourceFlag = true;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                LoadProgramGrid();
            }
        }

        protected void CmbManifestation_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strManifestVal = ((DropDownList)sender).SelectedValue;
            ViewState["ManifestValue"] = strManifestVal;

            if (ViewState["SourceFlag"] != null)
            {
                blnSourceFlag = (bool)ViewState["SourceFlag"];

                if (!blnSourceFlag)
                    blnSourceFlag = true;
            }

            if (ViewState["ProgramList"] != null && !blnSourceFlag)
            {
                lstProgram = (List<Program>)ViewState["ProgramList"];
            }
            else
            {
                Program program = new Models.Program();
                lstProgram = program.Programs;
            }

            if (lstProgram != null)
            {
                if(ViewState["ProgramTitle"] !=null)
                {
                    grdUsers.DataSource = ViewState["ProgramList"] = lstProgram.FindAll(program => (program.Manifestation.ToUpper() == strManifestVal.ToUpper() && program.ProgramTitle.ToUpper() == ViewState["ProgramTitle"].ToString().ToUpper())).ToList();
                }
                else
                { 
                    grdUsers.DataSource = ViewState["ProgramList"] = lstProgram.FindAll(program => program.Manifestation.ToUpper() == strManifestVal.ToUpper()).ToList();
                }
                grdUsers.DataBind();
            }
            blnSourceFlag = false;
            ViewState["SourceFlag"] = blnSourceFlag;
        }


        protected void cmbProgramTitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strProgramTitle = ((DropDownList)sender).SelectedValue;
            ViewState["ProgramTitle"] = strProgramTitle;

            if (ViewState["SourceFlag"] != null)
            {
                blnSourceFlag = (bool)ViewState["SourceFlag"];

                if (!blnSourceFlag)
                    blnSourceFlag = true;
            }

            if (ViewState["ProgramList"] != null && !blnSourceFlag)
            {
                lstProgram = (List<Program>)ViewState["ProgramList"];
            }
            else
            {
                Program program = new Models.Program();
                lstProgram = program.Programs;
            }

            if (lstProgram != null)
            {
                if (ViewState["ManifestValue"] != null)
                {
                    grdUsers.DataSource = ViewState["ProgramList"] = lstProgram.FindAll(program => (program.ProgramTitle.ToUpper() == strProgramTitle.ToUpper() && program.Manifestation.ToUpper() == ViewState["ManifestValue"].ToString().ToUpper())).ToList();
                }
                else
                {
                    grdUsers.DataSource = ViewState["ProgramList"] = lstProgram.FindAll(program => program.ProgramTitle.ToUpper() == strProgramTitle.ToUpper()).ToList();
                }
                grdUsers.DataBind();
            }
        }

        protected void GrdUsers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                DropDownList cmbManifestation = (DropDownList)e.Row.FindControl("cmbManifestation");
                DropDownList cmbProgramTitle = (DropDownList)e.Row.FindControl("cmbProgramTitle");

                if (lstProgram != null)
                {
                    var lstManifestation = lstProgram.Select(program => program.Manifestation).Distinct().ToList();
                    var lstProgramTitle = lstProgram.Select(program => program.ProgramTitle).Distinct().ToList();

                    if (cmbManifestation != null)
                    {
                        cmbManifestation.DataSource = lstManifestation;
                        cmbManifestation.DataBind();
                        cmbManifestation.Items.Insert(0, new ListItem(" ", string.Empty));

                        cmbProgramTitle.DataSource = lstProgramTitle;
                        cmbProgramTitle.DataBind();
                        cmbProgramTitle.Items.Insert(0, new ListItem(" ", string.Empty));

                        if (ViewState["ManifestValue"] != null)
                        {
                            cmbManifestation.SelectedValue = ViewState["ManifestValue"].ToString();
                        }

                        if (ViewState["ProgramTitle"] != null)
                        {
                            cmbProgramTitle.SelectedValue = ViewState["ProgramTitle"].ToString();
                        }
                    }
                }
                else
                {
                    cmbManifestation.Items.Add(new ListItem("-", string.Empty));
                    cmbProgramTitle.Items.Add(new ListItem("-", string.Empty));
                }

            }
        }

        private void LoadProgramGrid()
        {
            Program program = new Models.Program();
            lstProgram = program.Programs;
            grdUsers.DataSource = lstProgram;
            grdUsers.DataBind();
            ViewState["ProgramList"] = lstProgram;

        }        

        protected void grdUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdUsers.PageIndex = e.NewPageIndex;
            LoadProgramGrid();
        }
    }
}